require('dotenv').config();
const OpenAI = require('openai');
const fetch = require('node-fetch');
const https = require('https');
const { authenticate, readTokenFromDB } = require('./refreshTokenKommo');
const { getKommoSessionFromDB, refreshKommoSession } = require('./kommoSessionService');
const systemPrompt = require('../config/systemPrompt');
const tools = require('../config/toolDefinitions');

// Deshabilita keep-alive para evitar sockets reutilizados a medio cerrar,
// una causa común de ERR_STREAM_PREMATURE_CLOSE contra la API de Kommo.
const kommoAgent = new https.Agent({ keepAlive: false });

const RETRIABLE_CODES = new Set(['ERR_STREAM_PREMATURE_CLOSE', 'ECONNRESET', 'ETIMEDOUT', 'EPIPE']);

// Wrapper de fetch con reintentos ante fallos de red transitorios
// (ej. la conexión con Kommo se corta a mitad de la respuesta).
async function fetchWithRetry(url, options = {}, retries = 2, delayMs = 500) {
  const fetchOptions = { ...options, agent: kommoAgent };
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fetch(url, fetchOptions);
    } catch (err) {
      const isRetriable = RETRIABLE_CODES.has(err.code) || RETRIABLE_CODES.has(err.errno);
      if (!isRetriable || attempt === retries) {
        throw err;
      }
      console.warn(`fetch a ${url} falló (intento ${attempt + 1}/${retries + 1}): ${err.message}. Reintentando...`);
      await new Promise((resolve) => setTimeout(resolve, delayMs * (attempt + 1)));
    }
  }
}

// Clase que encapsula la lógica para interactuar con la API de OpenAI
class OpenAIService {
  constructor() {
    const apiKey = process.env.OPENAI_API_KEY;
    // keepAlive: false evita reutilizar sockets a medio cerrar, la misma causa
    // de ERR_STREAM_PREMATURE_CLOSE que ya vimos contra Kommo.
    const openaiAgent = new https.Agent({ keepAlive: false });
    this.openai = new OpenAI({ apiKey: apiKey, httpAgent: openaiAgent });
    // Map para almacenar contexto de conversaciones (temporal, en producción usar base de datos)
    this.conversationContexts = new Map();
  }

  // Detecta errores de red transitorios (incluye los envueltos en `cause`,
  // como OpenAIError -> Premature close proveniente de node-fetch).
  isRetriableStreamError(error) {
    const codes = [error?.code, error?.errno, error?.cause?.code, error?.cause?.errno];
    return codes.some((code) => code && RETRIABLE_CODES.has(code));
  }

  // Ejecuta el stream de Responses API con reintentos ante cortes de conexión
  // transitorios. Es seguro reintentar completo: no se emite nada al usuario
  // hasta que el stream termina, así que no hay efectos duplicados.
  async streamOpenAIResponse(requestParams, retries = 2, delayMs = 500) {
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const stream = await this.openai.responses.stream(requestParams);
        let currentResponse = null;
        const toolCallItems = [];

        for await (const event of stream) {
          // Guardar la respuesta completa cuando termine
          // Intentar múltiples tipos de eventos
          if (event.type === 'response.done' || event.type === 'done' || event.response) {
            currentResponse = event.response || event;
            console.log('Respuesta completa recibida:', JSON.stringify(currentResponse).substring(0, 200));

            // Buscar tool calls en los output items
            if (currentResponse.output) {
              for (const item of currentResponse.output) {
                if (item.type === 'function_call') {
                  toolCallItems.push(item);
                }
              }
            }
          }
        }

        return { currentResponse, toolCallItems };
      } catch (error) {
        const isRetriable = this.isRetriableStreamError(error);
        if (!isRetriable || attempt === retries) {
          throw error;
        }
        console.warn(`Stream de OpenAI falló (intento ${attempt + 1}/${retries + 1}): ${error.message}. Reintentando...`);
        await new Promise((resolve) => setTimeout(resolve, delayMs * (attempt + 1)));
      }
    }
  }

  // Obtener el token desde la base de datos
  async getToken() {
    const domain = process.env.SUBDOMINIO;
    const tokenData = await readTokenFromDB(domain);
    return tokenData.access_token;
  }

  // Método helper para hacer fetch con retry automático si el token está vencido
  async fetchWithTokenRetry(url, options, retryCount = 0) {
    const MAX_RETRIES = 1;
    
    try {
      const response = await fetchWithRetry(url, options);

      // Si obtenemos un 401 (Unauthorized), el token podría estar vencido
      if (response.status === 401 && retryCount < MAX_RETRIES) {
        console.log('Token inválido (401), actualizando token...');
        
        // Refrescar el token
        await authenticate();
        
        // Obtener el nuevo token
        const newToken = await this.getToken();
        
        // Actualizar el header de autorización en las opciones
        options.headers.Authorization = 'Bearer ' + newToken;
        options.headers.authorization = 'Bearer ' + newToken;
        
        // Reintentar la solicitud con el nuevo token
        console.log('Reintentando solicitud con token actualizado...');
        return await this.fetchWithTokenRetry(url, options, retryCount + 1);
      }
      
      return response;
    } catch (error) {
      console.error('Error en fetchWithTokenRetry:', error);
      throw error;
    }
  }

  async parseJsonResponse(response, operationName) {
    const contentType = (response.headers.get('content-type') || '').toLowerCase();
    const bodyText = await response.text();

    let json = null;
    if (bodyText) {
      try {
        json = JSON.parse(bodyText);
      } catch (parseError) {
        json = null;
      }
    }

    if (!response.ok) {
      const bodyPreview = bodyText ? bodyText.slice(0, 300).replace(/\s+/g, ' ').trim() : '(sin body)';
      throw new Error(
        `${operationName}: ${response.status} ${response.statusText}. ` +
        `Content-Type: ${contentType || 'desconocido'}. Body: ${bodyPreview}`
      );
    }

    if (!json) {
      const bodyPreview = bodyText ? bodyText.slice(0, 300).replace(/\s+/g, ' ').trim() : '(sin body)';
      throw new Error(
        `${operationName}: respuesta no JSON valida. ` +
        `Content-Type: ${contentType || 'desconocido'}. Body: ${bodyPreview}`
      );
    }

    return json;
  }

  async main(msg_client, conversationId, lead_id) {
    try {
      const lastMessage = await this.createResponse(msg_client, conversationId, lead_id);
      return lastMessage;
    } catch (error) {
      console.error("Error en main:", error);
      // Si hay cualquier error, transferir a un asesor (solo si lead_id existe)
      if (lead_id) {
        try {
          await this.getInterest("ASESOR", lead_id);
        } catch (fallbackError) {
          console.error("Error en la transferencia a asesor:", fallbackError);
        }
      }
      return "Espera un minuto y ya te atiendo";
    }
  }

  // Crear una nueva conversación (genera un ID único)
  async createdConversation() {
    // Generar un ID único para la conversación
    const conversationId = 'conv_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    // Inicializar el contexto de la conversación
    this.conversationContexts.set(conversationId, {
      messages: [],
      lastResponseId: null,
      createdAt: new Date()
    });
    console.log('Nueva conversación creada:', conversationId);
    return conversationId;
  }

  // Eliminar una conversación existente
  async deletedConversation(conversation_id) {
    if (this.conversationContexts.has(conversation_id)) {
      this.conversationContexts.delete(conversation_id);
      console.log('Conversación eliminada:', conversation_id);
    }
  }

  // Obtener contexto de una conversación
  getConversationContext(conversation_id) {
    return this.conversationContexts.get(conversation_id) || null;
  }

  // Actualizar contexto de una conversación
  updateConversationContext(conversation_id, updates) {
    const context = this.conversationContexts.get(conversation_id);
    if (context) {
      Object.assign(context, updates);
      this.conversationContexts.set(conversation_id, context);
    }
  }

  // En Responses API, los mensajes se envían directamente como input en createResponse()
  // Esta función se mantiene para compatibilidad pero ya no se usa
    async addMessageToConversation(conversationId, msg_client) {
      // En Responses API los mensajes se agregan automáticamente a la conversación
      // cuando usamos el parámetro conversation en responses.create()
      return { role: "user", content: msg_client };
    }
  
  async createResponse(msg_client, conversationId, lead_id) {
    try {
      if (!msg_client || typeof msg_client !== 'string' || msg_client.trim() === '') {
        throw new Error("Missing or invalid required parameter: 'msg_client'");
      }

      let context = conversationId ? this.getConversationContext(conversationId) : null;
      let previousResponseId = null;

      const input = [];

      if (context && context.messages.length > 0) {
        previousResponseId = context.lastResponseId;
      } else {
        input.push({ role: "system", content: systemPrompt });
      }

      input.push({ role: "user", content: msg_client.trim() });

      const model = process.env.OPENAI_MODEL || 'gpt-4.1-mini';

      const requestParams = {
        model: model,
        input: input,
        tools: tools,
        text: {
          format: {
            type: "text"
          }
        },
        max_output_tokens: 2048,
        store: true
      };

      // Agregar previous_response_id si existe
      if (previousResponseId) {
        requestParams.previous_response_id = previousResponseId;
      }

      console.log('Creando respuesta con Responses API...');
      console.log('Input:', JSON.stringify(input));
      const { currentResponse, toolCallItems } = await this.streamOpenAIResponse(requestParams);
      const needsToolHandling = toolCallItems.length > 0;

      // Si hay tool calls que manejar, procesarlos. El modelo puede encadenar
      // varias rondas de tools (ej. buscar_producto y luego calcular_cotizacion
      // con el resultado), así que se itera hasta que ya no pida más tools.
      if (needsToolHandling && toolCallItems.length > 0) {
        let response = currentResponse;
        let pendingToolCalls = toolCallItems;
        const MAX_TOOL_ROUNDS = 6;
        let round = 0;

        while (pendingToolCalls.length > 0 && round < MAX_TOOL_ROUNDS) {
          round++;
          const toolOutputItems = [];

          for (const toolCall of pendingToolCalls) {
            const args = JSON.parse(toolCall.arguments);
            console.log("ToolCall detectado:", toolCall.name);
            console.log("Argumentos procesados:", args);

            const outputValue = await this.executeToolCall(toolCall.name, args, lead_id);

            toolOutputItems.push({
              type: 'function_call_output',
              call_id: toolCall.call_id,
              output: JSON.stringify(outputValue)
            });
          }

          const followUpRequestParams = {
            model: model,
            input: toolOutputItems,
            previous_response_id: response.id,
            tools: tools,
            store: true
          };

          response = await this.openai.responses.create(followUpRequestParams);
          pendingToolCalls = (response.output || []).filter((item) => item.type === 'function_call');
        }

        if (pendingToolCalls.length > 0) {
          console.warn(`Se alcanzó el máximo de ${MAX_TOOL_ROUNDS} rondas de tool calls sin obtener una respuesta final.`);
        }

        // Actualizar contexto de la conversación
        if (conversationId) {
          this.updateConversationContext(conversationId, {
            lastResponseId: response.id,
            messages: [...(context?.messages || []),
              { role: 'user', content: msg_client },
              { role: 'assistant', content: this.extractTextFromResponse(response) }
            ]
          });
        }

        // Extraer y retornar el texto de la respuesta final
        return this.extractTextFromResponse(response);
      }

      // Si no hay tool calls, retornar el texto directamente
      if (currentResponse) {
        // Actualizar contexto de la conversación
        if (conversationId) {
          this.updateConversationContext(conversationId, {
            lastResponseId: currentResponse.id,
            messages: [...(context?.messages || []), 
              { role: 'user', content: msg_client },
              { role: 'assistant', content: this.extractTextFromResponse(currentResponse) }
            ]
          });
        }

        return this.extractTextFromResponse(currentResponse);
      }

      throw new Error("No se recibió respuesta del modelo");

    } catch (error) {
      console.error("Error en createResponse:", error);
      // En caso de error, llamar a getInterest con "ASESOR" solo si hay lead_id
      if (lead_id) {
        try {
          await this.getInterest("ASESOR", lead_id);
          return "Espera un minuto y ya te atiendo";
        } catch (fallbackError) {
          console.error("Error en la transferencia a asesor:", fallbackError);
          return "Espera un minuto y ya te atiendo";
        }
      } else {
        // Modo prueba: retornar el error sin transferir
        return "Espera un minuto y ya te atiendo";
      }
    }
  }

  // Ejecuta una tool call individual y retorna su output
  async executeToolCall(toolName, args, lead_id) {
    if (toolName === 'unknow_message') {
      const customer_message = args.customer_message;
      const action_id = args.action_id;
      console.log(`Mensaje del cliente: ${customer_message}`);
      console.log(`ID de acción: ${action_id}`);
      if (lead_id) {
        return await this.postAppScriptAndKommo(action_id, customer_message, lead_id);
      }
      return { success: true, message: '[MODO PRUEBA] Mensaje procesado' };
    }

    if (toolName === 'send_asesor') {
      const action_id = args.action_id;
      console.log(`ID de acción para enviar a asesor: ${action_id}`);
      if (lead_id) {
        return await this.getInterest(action_id, lead_id);
      }
      return { success: true, message: '[MODO PRUEBA] Acción de envío a asesor procesada' };
    }

    if (toolName === 'cotizado') {
      const action_id = args.action_id;
      console.log(`ID de acción para cotizado: ${action_id}`);
      if (lead_id) {
        return await this.getInterest(action_id, lead_id);
      }
      return { success: true, message: '[MODO PRUEBA] Acción de cotizado procesada' };
    }

    if (toolName === 'finalizado') {
      const action_id = args.action_id;
      console.log(`ID de acción para finalizado: ${action_id}`);
      if (lead_id) {
        return await this.getInterest(action_id, lead_id);
      }
      return { success: true, message: '[MODO PRUEBA] Acción de finalizado procesada' };
    }

    if (toolName === 'buscar_producto') {
      const { buscarProducto: buscarEnJSON } = require('../utils/buscarProducto');
      console.log('Buscando producto con args:', args);
      return buscarEnJSON(args);
    }

    if (toolName === 'calcular_cotizacion') {
      const { calcularCotizacion } = require('../utils/calcularCotizacion');
      console.log('Calculando cotización con args:', args);
      return calcularCotizacion(args);
    }

    console.warn(`Tool call desconocida: ${toolName}`);
    return { success: false, message: `Tool call desconocida: ${toolName}` };
  }

  // Helper para extraer texto de una respuesta
  extractTextFromResponse(response) {
    for (const item of response.output) {
      if (item.type === 'message' && item.content) {
        for (const content of item.content) {
          if (content.type === 'output_text') {
            let text = content.text;
            // Limpiar referencias
            text = text.replace(/【\d+:\d+†[^】]+】/g, '');
            // Verificar si el mensaje contiene Markdown
            const markdownPattern = /(\*\*|_|~~|`|# |\* |- )/;
            if (markdownPattern.test(text)) {
              text = this.transformMarkdownToWhatsApp(text);
            }
            return text;
          }
        }
      }
    }
    return response.output_text || "Lo siento, no pude generar una respuesta.";
  }
  

  transformMarkdownToWhatsApp(markdownText) {
    // Reemplazar negritas
    let whatsappText = markdownText.replace(/\*\*(.*?)\*\*/g, '*$1*');
    
    // Reemplazar cursivas
    whatsappText = whatsappText.replace(/_(.*?)_/g, '_$1_');
    
    // Reemplazar tachado
    whatsappText = whatsappText.replace(/~~(.*?)~~/g, '~$1~');
    
    // Reemplazar monoespaciado
    whatsappText = whatsappText.replace(/`(.*?)`/g, '```$1```');
    
    // Reemplazar títulos y subtítulos
    whatsappText = whatsappText.replace(/^# (.*$)/gim, '*$1*');
    whatsappText = whatsappText.replace(/^## (.*$)/gim, '*$1*');
    whatsappText = whatsappText.replace(/^### (.*$)/gim, '*$1*');
    
    // Reemplazar viñetas
    whatsappText = whatsappText.replace(/^\* (.*$)/gim, '- $1');
    whatsappText = whatsappText.replace(/^- (.*$)/gim, '- $1');
    
    return whatsappText;
  }

// async buscarProducto(consulta) {
//   const buscarPromptId = process.env.PROMPT_ID_BUSCAR;
//   if (!buscarPromptId) {
//     console.error('PROMPT_ID_BUSCAR no está configurado en las variables de entorno');
//     return { success: false, message: 'No se pudo realizar la búsqueda de producto en este momento.' };
//   }

//   if (!consulta || typeof consulta !== 'string' || consulta.trim() === '') {
//     return { success: false, message: 'Consulta inválida para buscar producto.' };
//   }
 
//   try {
//     const { buscarProducto: buscarEnJSON } = require('../utils/buscarProducto');
//     const consultaLimpia = consulta.trim();
//     console.log('Buscando producto:', consultaLimpia);
 
//     const response = await this.openai.responses.create({
//       prompt: { id: buscarPromptId, version: "7" },
//       input: [{ role: 'user', content: consultaLimpia }],
//       text: { format: { type: 'text' } },
//       max_output_tokens: 1024,
//       store: false
//     });

//     // ── Verificar si el agente buscador disparó el tool call ──────────────────
//     const toolCalls = response.output?.filter(item => item.type === 'function_call') || [];

//     if (toolCalls.length > 0) {
//       const toolOutputItems = [];

//       for (const toolCall of toolCalls) {
//         const args = JSON.parse(toolCall.arguments);
//         console.log('Agente buscador llamó buscar_producto con:', args);

//         const resultadoJSON = buscarEnJSON(args);
//         console.log('Resultado local:', JSON.stringify(resultadoJSON).substring(0, 200));

//         toolOutputItems.push({
//           type: 'function_call_output',
//           call_id: toolCall.call_id,
//           output: JSON.stringify(resultadoJSON)
//         });
//       }

//       // ── Segunda llamada con el resultado del tool ─────────────────────────
//       // Usar la misma versión de prompt que devolvió la primera respuesta
//       const followUpVersion = response?.prompt?.version || "7";
//       const followUp = await this.openai.responses.create({
//         prompt: { id: buscarPromptId, version: followUpVersion },
//         input: toolOutputItems,
//         previous_response_id: response.id,
//         text: { format: { type: 'text' } },
//         max_output_tokens: 1024,
//         store: false
//       });

//       let resultado = '';
//       for (const item of followUp.output) {
//         if (item.type === 'message' && item.content) {
//           for (const content of item.content) {
//             if (content.type === 'output_text') {
//               resultado = content.text;
//               resultado = resultado.replace(/【\d+:\d+†[^】]+】/g, '');
//               resultado = resultado.replace(/\[\d+:\d+\+[^\]]+\]/g, '');
//               break;
//             }
//           }
//         }
//       }

//       if (!resultado) resultado = followUp.output_text || '';
//       console.log('Resultado búsqueda:', resultado.substring(0, 200));
//       return { success: true, message: resultado };
//     }
 
//     // ── Si no hubo tool call, extraer texto directo ───────────────────────────
//     let resultado = '';
//     for (const item of response.output) {
//       if (item.type === 'message' && item.content) {
//         for (const content of item.content) {
//           if (content.type === 'output_text') {
//             resultado = content.text;
//             resultado = resultado.replace(/【\d+:\d+†[^】]+】/g, '');
//             resultado = resultado.replace(/\[\d+:\d+\+[^\]]+\]/g, '');
//             break;
//           }
//         }
//       }
//     }
 
//     if (!resultado) {
//       resultado = response.output_text || '';
//       resultado = resultado.replace(/【\d+:\d+†[^】]+】/g, '');
//     }
 
//     console.log('Resultado búsqueda:', resultado.substring(0, 200));
//     return { success: true, message: resultado };
 
//   } catch (error) {
//     console.error('Error en buscarProducto:', error);
//     return { success: false, message: 'Error al buscar el producto. Por favor intenta de nuevo.' };
//   }
// }
  // Enviar el valor de la call fuction para cambiar a un asesor
  async getInterest(action_id, lead_id) {
    // Asegurarse de que el token es válido antes de realizar la solicitud
    await authenticate();
  
    console.log('action_id:', action_id); // Log para depuración
    console.log('lead_id:', lead_id); // Log para depuración
  
    const token = await this.getToken();
    const options = {
      method: 'PATCH',
      headers: {
        accept: 'application/json',
        'content-type': 'application/json',
        authorization: 'Bearer ' + token
      },
      body: JSON.stringify([{
        id: Number(lead_id),
        custom_fields_values: [
          { field_id: 1761296, values: [{ value: action_id }] }
        ]
      }])
    };
  
    try {
      const subdominio = process.env.SUBDOMINIO;
      const response = await this.fetchWithTokenRetry(`https://${subdominio}.kommo.com/api/v4/leads`, options);
      console.log('response status:', response.status); // Log para depuración
      const responseBody = await this.parseJsonResponse(response, 'Obtener leads Kommo');
      console.log('responseBody:', responseBody); // Log para depuración
  
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return { success: true, message: 'Se actualizó el lead' };
    } catch (err) {
      console.error("Error en la solicitud:", err);
      return { success: false, message: 'Error al actualizar el lead' };
    }
  }


  async processRequestData(request) {
    try {
      console.log('request.body:', request.body); // Log para depuración del cuerpo de la solicitud
  
      const formData = request.body;
      console.log('formData:', formData); // Log para depuración
      const parsedData = {};
      for (const key in formData) {
        const value = Array.isArray(formData[key]) ? formData[key][0] : formData[key];
        parsedData[key] = value;
      }
      console.log('parsedData:', parsedData); // Log para depuración
  
      const idLead = formData.leads.add[0].id;
      console.log('idLead:', idLead); // Log para depuración
      if (!idLead) {
        throw new Error('idLead no encontrado en los datos del formulario');
      }
  
      const token = await this.getToken();
      console.log('Token:', token); // Log para depuración
      const optionsGetLead = {
        method: 'get',
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer ' + token,
          'Content-Type': 'application/json',
        }
      };
  
      const subdominio = process.env.SUBDOMINIO;
      console.log('subdominio:', subdominio); // Log para depuración
      const response_get = await this.fetchWithTokenRetry(`https://${subdominio}.kommo.com/api/v4/leads/${idLead}`, optionsGetLead);
      console.log('response_get status:', response_get.status); // Log para depuración
      const responseBody = await this.parseJsonResponse(response_get, `Obtener lead Kommo ${idLead}`);
      console.log('responseBody:', responseBody); // Log para depuración
  
      if (!responseBody.custom_fields_values) {
        throw new Error('custom_fields_values no encontrado en la respuesta');
      }

      // mensaje del cliente
      const msj_client = responseBody.custom_fields_values.find((obj) => obj.field_id === 1761300);
      console.log('msj_client:', msj_client); // Log para depuración
      let msj_client_value = msj_client?.values?.[0]?.value;
            
      console.log('msj_client_value:', msj_client_value); // Log para depuración
  
      const conversation_id = responseBody.custom_fields_values.find((obj) => obj.field_id === 1761294);
      console.log('conversation_id:', conversation_id); // Log para depuración
      let conversation_id_value = conversation_id?.values?.[0]?.value || null;
      console.log('conversation_id_value:', conversation_id_value); // Log para depuración
      
      // Crear una nueva conversación si no se proporciona una
      if (!conversation_id_value) {
        console.log('Creando una nueva conversación'); // Log para depuración
        conversation_id_value = await this.createdConversation();
        console.log('Nuevo conversation_id_value:', conversation_id_value); // Log para depuración
      }
  
      // Llamar a las funciones correspondientes con los valores obtenidos
      if (conversation_id_value) {
        console.log('Llamando a main con conversation_id_value y msj_client_value'); // Log para depuración
        // Ya no necesitamos waitForActiveResponseToFinish en Responses API
        console.log('Llamando a main con:', { conversation_id_value, msj_client_value });
        const message = await this.main(msj_client_value, conversation_id_value, idLead);
        console.log('Mensaje obtenido:', message); // Log para depuración
  
        // Actualizar el campo personalizado en Kommo con el mensaje obtenido
        console.log('Actualizando el campo personalizado en Kommo'); // Log para depuración
        console.log('Llamando a updateLeadCustomField con:', { idLead, message, conversation_id_value });
        await this.updateLeadCustomField(idLead, message, conversation_id_value);
        console.log('Campo personalizado actualizado'); // Log para depuración
      }
      return {
        msj_client: msj_client_value,
        lead_id: idLead,
        conversation_id: conversation_id_value
      };
    } catch (error) {
      console.error("Error procesando los datos de la solicitud:", error);
      return null;
    }
  }


  async updateLeadCustomField(lead_id, value, conversation_id) {
    try {
      await authenticate();
    
      if (!lead_id || !value || !conversation_id) {
        throw new Error("Missing required parameters for updating lead custom field.");
      }
    
      const token = await this.getToken();
      const options = {
        method: 'PATCH',
        headers: {
          accept: 'application/json',
          'content-type': 'application/json',
          authorization: 'Bearer ' + token
        },
        body: JSON.stringify([{
          id: Number(lead_id),
          custom_fields_values: [
            // IA TEXT RESPONSE
            { field_id: 1761294, values: [{ value: conversation_id }] }
          ]
        }])
      };
    
      const subdominio = process.env.SUBDOMINIO;
      const response = await this.fetchWithTokenRetry(`https://${subdominio}.kommo.com/api/v4/leads`, options);
      await this.launchSalesbot(lead_id, token, subdominio, value);

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`HTTP error! status: ${response.status}, response: ${errorText}`);
        // Si hay un error HTTP, transferir a asesor
        await this.getInterest("ASESOR", lead_id);
        return { success: false, message: 'Espera un minuto y ya te atiendo' };
      }
      
      return { success: true, message: 'Se actualizó el lead' };
    } catch (err) {
      console.error("Error en la solicitud:", err);
      // En caso de cualquier error, transferir a asesor
      await this.getInterest("ASESOR", lead_id);
      throw err;
    }
  }

  async launchSalesbot(idLead, token, subdominio, messageContent) {
    const baseUrl = `https://${subdominio}.kommo.com`;
    const headersApi = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + token,
    };
    let headersAjax = null;
    let templateId = null;
    let botId = null;
    let usedSessionRetry = false;
    const MAX_CREATE_BOT_ATTEMPTS = 2;

    try {
      // Paso 0: Obtener cookies de sesión (cache o refresh)
      const { sessionId, csrfToken, cookieHeader } = await this.getKommoSessionCookies(subdominio);
      headersAjax = this.buildKommoAjaxHeaders(baseUrl, token, sessionId, csrfToken, cookieHeader);

      // Paso 1: Crear chat template con el mensaje
      templateId = await this.createChatTemplate(baseUrl, headersApi, messageContent);

      // Paso 2: Crear salesbot vinculado al template (con un retry de sesión)
      for (let attempt = 1; attempt <= MAX_CREATE_BOT_ATTEMPTS; attempt++) {
        try {
          botId = await this.createSalesbotWithTemplate(baseUrl, headersAjax, templateId);
          break;
        } catch (error) {
          const canRetry = attempt < MAX_CREATE_BOT_ATTEMPTS && this.shouldRetrySalesbotCreation(error);
          if (!canRetry) {
            throw error;
          }

          usedSessionRetry = true;
          console.info('[KommoSession] Sesión temporalmente inválida en /ajax/v2/salesbot. Renovando sesión y reintentando...');
          const refreshed = await this.getKommoSessionCookies(subdominio, true);
          headersAjax = this.buildKommoAjaxHeaders(
            baseUrl,
            token,
            refreshed.sessionId,
            refreshed.csrfToken,
            refreshed.cookieHeader
          );
        }
      }

      // Paso 3: Ejecutar el bot en el lead
      await this.executeSalesbot(baseUrl, headersApi, botId, idLead);

      if (usedSessionRetry) {
        console.info('[KommoSession] Reintento de /ajax/v2/salesbot completado correctamente tras renovar la sesión.');
      }

      console.log('Bot ejecutado correctamente en lead:', idLead);

      // Pausa antes de limpiar
      await new Promise(r => setTimeout(r, 2000));

    } catch (error) {
      console.error('Error en launchSalesbot:', error);
    } finally {
      // Limpieza: eliminar bot y template
      if (botId && headersAjax) {
        try {
          await this.deleteSalesbotById(baseUrl, headersAjax, botId);
        } catch (err) {
          console.error('Error al eliminar el bot:', err.message);
        }
      }
      if (templateId) {
        try {
          await this.deleteChatTemplate(baseUrl, headersApi, templateId);
        } catch (err) {
          console.error('Error al eliminar el template:', err.message);
        }
      }

      // Ejecutar bot fijo 102014 después de limpiar
      this.launchFixedSalesbot(idLead, token, subdominio);
    }
  }

  launchFixedSalesbot(idLead, token, subdominio) {
    const botLaunch = JSON.stringify([{ bot_id: 61564, entity_type: 2, entity_id: idLead }]);
    fetchWithRetry(`https://${subdominio}.kommo.com/api/v2/salesbot/run`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json',
      },
      body: botLaunch,
    })
      .then(response => this.parseJsonResponse(response, 'Error al ejecutar bot fijo 102014'))
      .then(data => console.log('Respuesta del bot fijo 102014:', data))
      .catch(error => console.error('Error al ejecutar el bot fijo 102014:', error));
  }

  async getKommoSessionCookies(subdominio, forceRefresh = false) {
    if (forceRefresh) {
      return refreshKommoSession(subdominio);
    }

    try {
      return await getKommoSessionFromDB(subdominio);
    } catch (_dbError) {
      return refreshKommoSession(subdominio);
    }
  }

  buildKommoAjaxHeaders(baseUrl, token, sessionId, csrfToken, cookieHeader) {
    return {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + token,
      'Cookie': cookieHeader || `session_id=${sessionId}; csrf_token=${csrfToken}`,
      'Origin': baseUrl,
      'Referer': `${baseUrl}/`,
      'X-CSRF-TOKEN': csrfToken,
      'X-Requested-With': 'XMLHttpRequest',
    };
  }

  shouldRetrySalesbotCreation(error) {
    return Boolean(
      error && (
        error.code === 'KOMMO_AJAX_NON_JSON' ||
        error.code === 'KOMMO_AJAX_AUTH_HTML' ||
        error.message?.includes('Error creando salesbot: 401') ||
        error.message?.includes('Error creando salesbot: 403')
      )
    );
  }

  async createChatTemplate(baseUrl, headers, messageContent) {
    console.log('Creando chat template...');
    const res = await fetchWithRetry(`${baseUrl}/api/v4/chats/templates`, {
      method: 'POST',
      headers,
      body: JSON.stringify([{ name: 'rt_magique_bot_template', content: messageContent }]),
    });

    const json = await this.parseJsonResponse(res, 'Error creando template');

    const template = json?._embedded?.chat_templates?.[0];
    if (!template?.id) throw new Error('No se pudo obtener el ID del template creado');

    console.log(`Template creado → ID: ${template.id}`);
    return template.id;
  }

  async createSalesbotWithTemplate(baseUrl, headersAjax, templateId) {
    console.log(`Creando salesbot con template_id: ${templateId}...`);
    const companyName = (process.env.SUBDOMINIO || 'empresa')
      .replace(/[-_]+/g, ' ')
      .replace(/\b\w/g, (char) => char.toUpperCase());

    const botText = JSON.stringify({
      "0": {
        question: [{
          handler: 'send_message',
          params: {
            type: 'external',
            tag: '',
            send_to_all_chat_sources: true,
            recipient: { type: 'all_contacts', way_of_communication: 'over_all' },
            is_in_starting_block: false,
            template_id: templateId,
            on_error: null,
          },
        }],
      },
      conversation: false,
    });

    const res = await fetchWithRetry(`${baseUrl}/ajax/v2/salesbot`, {
      method: 'POST',
      headers: headersAjax,
      body: JSON.stringify({
        salesbot: [{
          id: 0,
          is_deleted: false,
          name: `${companyName} Bot (auto)`,
          type: 2,
          is_active: true,
          is_launched: false,
          selected: true,
          settings: { type_functionality: 0 },
          text: botText,
        }],
      }),
    });

    const raw = await res.text();
    let json = null;

    try {
      json = raw ? JSON.parse(raw) : null;
    } catch (_parseError) {
      const contentType = res.headers.get('content-type') || 'desconocido';
      const bodyPreview = raw ? raw.substring(0, 250).replace(/\s+/g, ' ').trim() : '[vacio]';

      const nonJsonError = new Error(
        `Respuesta no JSON al crear salesbot (${res.status}, content-type: ${contentType}). ` +
        `Vista previa: ${bodyPreview}`
      );
      nonJsonError.code = 'KOMMO_AJAX_NON_JSON';
      if (/text\/html|<!doctype|<html|login|auth|csrf/i.test(`${contentType} ${bodyPreview}`)) {
        nonJsonError.code = 'KOMMO_AJAX_AUTH_HTML';
      }
      throw nonJsonError;
    }

    if (!res.ok) {
      throw new Error(`Error creando salesbot: ${res.status} ${JSON.stringify(json)}`);
    }

    const bot = json?._embedded?.items?.[0];
    if (!bot?.id) throw new Error('No se pudo obtener el ID del bot creado');

    console.log(`Salesbot creado → ID: ${bot.id}`);
    return bot.id;
  }

  async executeSalesbot(baseUrl, headers, botId, leadId) {
    console.log(`Ejecutando bot ${botId} en lead ${leadId}...`);
    const res = await fetchWithRetry(`${baseUrl}/api/v4/bots/${botId}/run`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ entity_id: leadId, entity_type: 'leads' }),
    });

    const raw = await res.text();
    let json = null;

    if (raw) {
      try {
        json = JSON.parse(raw);
      } catch (_parseError) {
        if (!res.ok) {
          throw new Error(`Error ejecutando bot: ${res.status} Respuesta no JSON: ${raw.substring(0, 250)}`);
        }

        console.log('Bot ejecutado con respuesta no JSON:', raw.substring(0, 200));
        return { success: true, status: res.status, raw };
      }
    }

    if (!res.ok) {
      throw new Error(`Error ejecutando bot: ${res.status} ${JSON.stringify(json)}`);
    }

    console.log('Bot ejecutado:', json || { success: true, status: res.status, message: 'Sin body' });
    return json || { success: true, status: res.status, message: 'Bot ejecutado sin cuerpo de respuesta' };
  }

  async deleteSalesbotById(baseUrl, headersAjax, botId) {
    console.log(`Eliminando salesbot ID: ${botId}...`);
    const res = await fetchWithRetry(`${baseUrl}/ajax/v2/salesbot/`, {
      method: 'DELETE',
      headers: headersAjax,
      body: JSON.stringify([botId]),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Error eliminando bot: ${res.status} ${text}`);
    }
    console.log('Salesbot eliminado');
  }

  async deleteChatTemplate(baseUrl, headers, templateId) {
    console.log(`Eliminando template ID: ${templateId}...`);
    const res = await fetchWithRetry(`${baseUrl}/api/v4/chats/templates/${templateId}`, {
      method: 'DELETE',
      headers,
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Error eliminando template: ${res.status} ${text}`);
    }
    console.log('Template eliminado');
  }

}

module.exports = OpenAIService;
